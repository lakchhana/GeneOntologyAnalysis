import pandas as pd


EXPERIMENTAL_CODES = ["EXP", "IDA", "IPI", "IMP", "IGI", "IEP"]


class Annotation:
    """
    Base class that represents one gene-to-GO-term annotation.
    """

    def __init__(self, gene_symbol, go_id, evidence_code, aspect, date):
        self._gene_symbol = gene_symbol
        self._go_id = go_id
        self._evidence_code = evidence_code
        self._aspect = aspect
        self._date = date

    @property
    def gene_symbol(self):
        return self._gene_symbol

    @property
    def go_id(self):
        return self._go_id

    @property
    def evidence_code(self):
        return self._evidence_code

    @property
    def aspect(self):
        return self._aspect

    @property
    def date(self):
        return self._date

    def describe(self):
        return self._gene_symbol + " -- " + self._go_id + " (" + self._evidence_code + ")"

    def reliability_score(self):
        return 0.5

    def __str__(self):
        return self.describe()

    def __repr__(self):
        return "Annotation(" + self.describe() + ")"


class ExperimentalAnnotation(Annotation):
    """
    Annotation supported by laboratory experimental evidence.
    """

    def describe(self):
        base_text = super().describe()
        return "[Experimental] " + base_text

    def reliability_score(self):
        return 1.0


class ElectronicAnnotation(Annotation):
    """
    Annotation created automatically by a computer program.
    """

    def describe(self):
        base_text = super().describe()
        return "[Electronic] " + base_text

    def reliability_score(self):
        return 0.5


def create_annotation(gene_symbol, go_id, evidence_code, aspect, date):
    """
    Create the correct Annotation object based on the evidence code.
    """

    if evidence_code in EXPERIMENTAL_CODES:
        return ExperimentalAnnotation(gene_symbol, go_id, evidence_code, aspect, date)

    if evidence_code == "IEA":
        return ElectronicAnnotation(gene_symbol, go_id, evidence_code, aspect, date)

    return Annotation(gene_symbol, go_id, evidence_code, aspect, date)


class AnnotationManager:
    """
    Stores annotations and provides methods to query them.
    """

    SAMPLE_SIZE = 50000

    def __init__(self):
        self._annotations = []
        self._by_gene = {}
        self._by_term = {}
        self._df = None

    def build_from_data(self, annotations_df):
        """
        Build the annotation collection from a pandas DataFrame.
        """

        self._df = annotations_df

        print("Building annotations...")

        total_rows = len(annotations_df)
        rows_to_process = min(self.SAMPLE_SIZE, total_rows)

        print("Total rows in DataFrame: " + str(total_rows))
        print("Building Annotation objects for first " + str(rows_to_process) + " rows...")

        sample_df = annotations_df.head(rows_to_process)
        counter = 0

        for index, row in sample_df.iterrows():
            gene_symbol = row["db_object_symbol"]
            go_id = row["go_id"]
            evidence_code = row["evidence_code"]
            aspect = row["aspect"]
            date = row["date"]

            annotation = create_annotation(
                gene_symbol,
                go_id,
                evidence_code,
                aspect,
                date
            )

            self._annotations.append(annotation)

            if gene_symbol not in self._by_gene:
                self._by_gene[gene_symbol] = []
            self._by_gene[gene_symbol].append(annotation)

            if go_id not in self._by_term:
                self._by_term[go_id] = []
            self._by_term[go_id].append(annotation)

            counter = counter + 1

            if counter % 10000 == 0:
                print("Processed " + str(counter) + " / " + str(rows_to_process) + " rows...")

        print("Building annotations... " + str(len(self._annotations)) + " annotation objects loaded")
        print("Unique genes (in objects): " + str(len(self._by_gene)))
        print("Unique GO terms (in objects): " + str(len(self._by_term)))

    def get_by_gene(self, symbol):
        """
        Get all Annotation objects for a given gene symbol.
        """

        if symbol in self._by_gene:
            return self._by_gene[symbol]

        return []

    def get_by_term(self, go_id):
        """
        Get all Annotation objects for a given GO term.
        """

        if go_id in self._by_term:
            return self._by_term[go_id]

        return []

    def get_by_evidence(self, code):
        """
        Get all Annotation objects with a specific evidence code.
        """

        results = []

        for annotation in self._annotations:
            if annotation.evidence_code == code:
                results.append(annotation)

        return results

    def get_terms_for_gene(self, symbol):
        """
        Get all GO term IDs that a gene is annotated with.
        Uses the full DataFrame.
        """

        if self._df is None:
            return []

        gene_rows = self._df[self._df["db_object_symbol"] == symbol]
        term_list = gene_rows["go_id"].unique().tolist()

        return term_list

    def get_genes_for_term(self, go_id):
        """
        Get all gene symbols that are annotated with a given GO term.
        Uses the full DataFrame.
        """

        if self._df is None:
            return []

        term_rows = self._df[self._df["go_id"] == go_id]
        gene_list = term_rows["db_object_symbol"].unique().tolist()

        return gene_list

    def summary(self):
        """
        Return summary statistics about all annotations.
        Uses the full DataFrame.
        """

        result = {}

        if self._df is None:
            result["total"] = 0
            result["by_namespace"] = {}
            result["by_evidence"] = {}
            return result

        result["total"] = len(self._df)

        namespace_counts = self._df["aspect"].value_counts()
        by_namespace = {}

        for aspect_code, count in namespace_counts.items():
            by_namespace[aspect_code] = int(count)

        result["by_namespace"] = by_namespace

        evidence_counts = self._df["evidence_code"].value_counts()
        by_evidence = {}

        for evidence_code, count in evidence_counts.items():
            by_evidence[evidence_code] = int(count)

        result["by_evidence"] = by_evidence

        return result

    def get_all_genes(self):
        """
        Return a sorted list of all unique gene symbols.
        Uses the full DataFrame.
        """

        if self._df is None:
            return []

        all_genes = self._df["db_object_symbol"].unique().tolist()
        all_genes.sort()

        return all_genes

    def get_top_genes(self, n=10):
        """
        Return the top N most-annotated genes.

        Each item is a tuple:
        (gene_symbol, annotation_count)
        """

        if self._df is None:
            return []

        gene_counts = self._df["db_object_symbol"].value_counts()
        top = gene_counts.head(n)

        result = []

        for gene_symbol, count in top.items():
            result.append((gene_symbol, int(count)))

        return result

    def get_top_terms(self, n=10):
        """
        Return the top N most-used GO terms.

        Each item is a tuple:
        (go_id, annotation_count)
        """

        if self._df is None:
            return []

        term_counts = self._df["go_id"].value_counts()
        top = term_counts.head(n)

        result = []

        for go_id, count in top.items():
            result.append((go_id, int(count)))

        return result

    def get_annotations_for_term(self, go_id, limit=50):
        """
        Get annotation details for a specific GO term.
        Uses the full DataFrame.
        """

        if self._df is None:
            return []

        term_rows = self._df[self._df["go_id"] == go_id]

        results = []

        for index, row in term_rows.head(limit).iterrows():
            results.append({
                "gene_symbol": row["db_object_symbol"],
                "evidence_code": row["evidence_code"],
            })

        return results

    def get_annotations_for_gene(self, symbol):
        """
        Get annotation details for a specific gene symbol.
        Uses the full DataFrame.
        """

        if self._df is None:
            return []

        gene_rows = self._df[self._df["db_object_symbol"] == symbol]

        if len(gene_rows) == 0:
            gene_upper = symbol.upper()

            if gene_upper != symbol:
                gene_rows = self._df[self._df["db_object_symbol"] == gene_upper]

        results = []

        for index, row in gene_rows.iterrows():
            results.append({
                "go_id": row["go_id"],
                "evidence_code": row["evidence_code"],
                "aspect": row.get("aspect", ""),
            })

        return results
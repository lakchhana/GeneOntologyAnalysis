# analysis/similarity.py
# This module defines classes that measure how similar two genes are.
# We compare genes by looking at which GO terms they share.
#
# Classes:
#   SimilarityMeasure   - base class (returns 0.0 by default)
#   JaccardSimilarity   - uses Jaccard index  (intersection / union)
#   OverlapSimilarity   - uses overlap coeff  (intersection / min size)



# SimilarityMeasure  (base class)

class SimilarityMeasure:
    """
    Base class for all similarity measures.
    Subclasses override the calculate() method with their own formula.
    """

    def __init__(self, annotation_manager):
       
        self._annotation_manager = annotation_manager

    def calculate(self, gene_a, gene_b):
        return 0.0

    def get_name(self):
        return "Base Similarity"

    def get_description(self):
        return "Base similarity measure"



# JaccardSimilarity

class JaccardSimilarity(SimilarityMeasure):
    """
    Jaccard similarity between two genes.

    The Jaccard index is calculated as:
        |intersection| / |union|

    The result is a number between 0.0 (nothing in common) and
    1.0 (exactly the same GO terms).
    """

    def calculate(self, gene_a, gene_b):
    
        terms_a = self._annotation_manager.get_terms_for_gene(gene_a)
        terms_b = self._annotation_manager.get_terms_for_gene(gene_b)

        set_a = set(terms_a)
        set_b = set(terms_b)
        if len(set_a) == 0 and len(set_b) == 0:
            return 0.0
        intersection = set_a.intersection(set_b)
        union = set_a.union(set_b)
        jaccard_score = len(intersection) / len(union)

        return jaccard_score

    def get_name(self):
        return "Jaccard Similarity"

    def get_description(self):
        return "Measures similarity as the size of the intersection divided by the size of the union of GO term sets."


# OverlapSimilarity

class OverlapSimilarity(SimilarityMeasure):
    """
    Overlap coefficient between two genes.

    The overlap coefficient is calculated as:
        |intersection| / min(|set_a|, |set_b|)

    This is useful when one gene has many more annotations than the other.
    If the smaller set is completely contained in the larger set,
    the overlap coefficient will be 1.0.
    """

    def calculate(self, gene_a, gene_b):
     
        terms_a = self._annotation_manager.get_terms_for_gene(gene_a)
        terms_b = self._annotation_manager.get_terms_for_gene(gene_b)
        set_a = set(terms_a)
        set_b = set(terms_b)
        
        if len(set_a) == 0 or len(set_b) == 0:
            return 0.0
        intersection = set_a.intersection(set_b)
        smaller_size = min(len(set_a), len(set_b))
        overlap_score = len(intersection) / smaller_size

        return overlap_score

    def get_name(self):
        return "Overlap Coefficient"

    def get_description(self):
        return "Measures similarity as the size of the intersection divided by the size of the smaller GO term set."

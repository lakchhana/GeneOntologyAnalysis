# analysis/statistics.py
# This module provides simple statistical functions for Gene Ontology analysis.
# These are plain functions that work with an AnnotationManager.
#
# Functions:
#   build_gene_term_matrix()   - create a binary matrix of genes vs GO terms
#   namespace_distribution()   - count annotations per namespace (BP, MF, CC)
#   evidence_distribution()    - count annotations per evidence code

import numpy as np
import pandas as pd



# build_gene_term_matrix()

def build_gene_term_matrix(annotation_manager, top_n=100):

    print("Building gene-term matrix...")
    top_genes = annotation_manager.get_top_genes(n=top_n)

    # Make a list of just the gene symbols
    gene_list = []
    for gene_symbol, count in top_genes:
        gene_list.append(gene_symbol)

    print("  Selected " + str(len(gene_list)) + " top genes")

    # For each gene, get its GO terms
    gene_terms_dict = {}
    all_terms_set = set()

    for gene in gene_list:
        terms = annotation_manager.get_terms_for_gene(gene)
        terms_set = set(terms)
        gene_terms_dict[gene] = terms_set
        for term in terms_set:
            all_terms_set.add(term)


    term_list = sorted(list(all_terms_set))

    print("  Found " + str(len(term_list)) + " unique GO terms")

    #  Create the matrix
    num_genes = len(gene_list)
    num_terms = len(term_list)
    matrix = np.zeros((num_genes, num_terms), dtype=int)

    # Fill in 1s where a gene has a GO term
    for i in range(num_genes):
        gene = gene_list[i]
        gene_terms = gene_terms_dict[gene]

        for j in range(num_terms):
            term = term_list[j]

            # Check if this gene has this GO term
            if term in gene_terms:
                matrix[i][j] = 1

        # Print progress every 25 genes
        if (i + 1) % 25 == 0:
            print("  Processed " + str(i + 1) + " / " + str(num_genes) + " genes...")

    print("  Matrix shape: " + str(num_genes) + " genes x " + str(num_terms) + " terms")
    print("Building gene-term matrix... done!")

    return matrix, gene_list, term_list


# namespace_distribution()

def namespace_distribution(annotation_manager):
    summary = annotation_manager.summary()

    # The summary has aspect codes like "P", "F", "C"
    # We want to map them to the nicer names "BP", "MF", "CC"
    aspect_to_namespace = {
        "P": "BP",
        "F": "MF",
        "C": "CC"
    }

    # Build the result dictionary
    dist = {}

    by_namespace = summary["by_namespace"]

    # Loop through the mapping and convert
    for aspect_code, namespace_name in aspect_to_namespace.items():
        if aspect_code in by_namespace:
            dist[namespace_name] = by_namespace[aspect_code]
        else:
            dist[namespace_name] = 0

    return dist



# evidence_distribution()

def evidence_distribution(annotation_manager):
    summary = annotation_manager.summary()

    dist = summary["by_evidence"]

    return dist



# matrix_summary()

def matrix_summary(annotation_manager, top_n=20):

    matrix, gene_list, term_list = build_gene_term_matrix(annotation_manager, top_n)

    # Count the total number of 1s in the matrix using NumPy
    total_ones = int(np.sum(matrix))
    num_genes = matrix.shape[0]
    num_terms = matrix.shape[1]
    total_cells = num_genes * num_terms
    if total_cells > 0:
        density = total_ones / total_cells
    else:
        density = 0.0

    # Average annotations per gene = mean of row sums
    row_sums = np.sum(matrix, axis=1)
    avg_per_gene = float(np.mean(row_sums))

    # Average genes per term = mean of column sums
    col_sums = np.sum(matrix, axis=0)
    avg_per_term = float(np.mean(col_sums))

    info = {
        "num_genes": num_genes,
        "num_terms": num_terms,
        "total_ones": total_ones,
        "density": round(density, 4),
        "avg_annotations_per_gene": round(avg_per_gene, 1),
        "avg_genes_per_term": round(avg_per_term, 1),
        "gene_list": gene_list,
    }

    return info



# gene_cosine_similarity()

def gene_cosine_similarity(annotation_manager, top_n=10):

    # Build the matrix
    matrix, gene_list, term_list = build_gene_term_matrix(annotation_manager, top_n)

    num_genes = len(gene_list)
    pairs = []

    # Compare every pair of genes
    for i in range(num_genes):
        for j in range(i + 1, num_genes):
        
            vec_a = matrix[i].astype(float)
            vec_b = matrix[j].astype(float)

            # Compute the dot product using NumPy
            dot_product = np.dot(vec_a, vec_b)

            # Compute the magnitude (L2 norm) of each vector
            norm_a = np.sqrt(np.sum(vec_a ** 2))
            norm_b = np.sqrt(np.sum(vec_b ** 2))

            # Compute cosine similarity
            if norm_a > 0 and norm_b > 0:
                score = dot_product / (norm_a * norm_b)
            else:
                score = 0.0

            pairs.append((gene_list[i], gene_list[j], round(float(score), 4)))

    # Sort by similarity score, highest first
    pairs.sort(key=lambda x: x[2], reverse=True)

    return pairs

# obo_parser.py
# This module reads and parses Gene Ontology OBO files.


import pandas as pd


class OBOParser:
    """
    A parser for OBO-format Gene Ontology files.

    The OBO file contains blocks like [Term] and [Typedef].
    We only care about [Term] blocks. Each term has fields like
    id, name, namespace, def, is_a, and is_obsolete.
    """

    def parse(self, filepath):

        print("Parsing OBO file...")   
        all_terms = []
        all_edges = []
        with open(filepath, "r") as f:
            lines = f.readlines()

        inside_term_block = False
        inside_typedef_block = False

        # Variables to hold the current term's data as we read it
        current_id = None
        current_name = None
        current_namespace = None
        current_definition = None
        current_is_obsolete = False
        current_parents = []  

        # Loop through each line in the file
        for line in lines:
            line = line.strip()
            if line == "[Term]":
                if inside_term_block and current_id is not None:
                    term_dict = {
                        "go_id": current_id,
                        "name": current_name,
                        "namespace": current_namespace,
                        "definition": current_definition,
                        "is_obsolete": current_is_obsolete,
                    }
                    all_terms.append(term_dict)

                    # Add all is_a edges for this term
                    for parent_id in current_parents:
                        all_edges.append((current_id, parent_id))

                # Reset everything for the new term
                inside_term_block = True
                inside_typedef_block = False
                current_id = None
                current_name = None
                current_namespace = None
                current_definition = None
                current_is_obsolete = False
                current_parents = []
                continue

            # Check if we hit a [Typedef] block 
            if line == "[Typedef]":
                if inside_term_block and current_id is not None:
                    term_dict = {
                        "go_id": current_id,
                        "name": current_name,
                        "namespace": current_namespace,
                        "definition": current_definition,
                        "is_obsolete": current_is_obsolete,
                    }
                    all_terms.append(term_dict)

                    for parent_id in current_parents:
                        all_edges.append((current_id, parent_id))

                # Mark that we are now in a typedef block                 inside_term_block = False
                inside_typedef_block = True
                current_id = None
                current_name = None
                current_namespace = None
                current_definition = None
                current_is_obsolete = False
                current_parents = []
                continue
            
            if inside_typedef_block:
                continue
            if not inside_term_block:
                continue
            # Parse the different fields we care about.
            if line.startswith("id:"):
                current_id = line[len("id:"):].strip()
            elif line.startswith("name:"):
                current_name = line[len("name:"):].strip()
            elif line.startswith("namespace:"):
                current_namespace = line[len("namespace:"):].strip()

            # Parse the definition — the text is between the first pair of quotes
            elif line.startswith("def:"):
                first_quote = line.find('"')
                second_quote = line.find('"', first_quote + 1)
                if first_quote != -1 and second_quote != -1:                 
                    current_definition = line[first_quote + 1 : second_quote]
                else:          
                    current_definition = line[len("def:"):].strip()

            # Parse is_a relationships 
            elif line.startswith("is_a:"):
                rest = line[len("is_a:"):].strip()
                parent_id = rest.split("!")[0].strip()
                current_parents.append(parent_id)

            # Check if the term is marked as obsolete
            elif line.startswith("is_obsolete:"):
                value = line[len("is_obsolete:"):].strip()
                if value == "true":
                    current_is_obsolete = True

        if inside_term_block and current_id is not None:
            term_dict = {
                "go_id": current_id,
                "name": current_name,
                "namespace": current_namespace,
                "definition": current_definition,
                "is_obsolete": current_is_obsolete,
            }
            all_terms.append(term_dict)

            for parent_id in current_parents:
                all_edges.append((current_id, parent_id))

        # convert the list of dictionaries into a pandas DataFrame
        terms_dataframe = pd.DataFrame(
            all_terms,
            columns=["go_id", "name", "namespace", "definition", "is_obsolete"],
        )
        print("Found " + str(len(all_terms)) + " terms")
        print("Found " + str(len(all_edges)) + " is_a edges")

        # Return the dataframe and edges as a tuple
        return (terms_dataframe, all_edges)

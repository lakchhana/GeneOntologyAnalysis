# parser/__init__.py
# This file makes the parser folder a Python package.

from parser.obo_parser import OBOParser
from parser.gaf_parser import GAFParser

class OntologyEntity:
    """
    Base class for all Gene Ontology entities.
    Stores the GO ID, name, namespace, and definition.
    """

    def __init__(self, go_id, name, namespace, definition):
        self._go_id = go_id
        self._name = name
        self._namespace = namespace
        self._definition = definition

    @property
    def go_id(self):
        return self._go_id

    @property
    def name(self):
        return self._name

    @property
    def namespace(self):
        return self._namespace

    @property
    def definition(self):
        return self._definition

    def describe(self):
        return self._go_id + " - " + self._name

    def get_info(self):
        info = {
            "go_id": self._go_id,
            "name": self._name,
            "namespace": self._namespace,
            "definition": self._definition,
        }
        return info

    def __str__(self):
        return self.describe()

    def __repr__(self):
        return "OntologyEntity(" + self._go_id + ")"


class GOTerm(OntologyEntity):
    """
    Represents a single Gene Ontology term.
    Inherits basic info from OntologyEntity and adds
    parent/child relationships and an obsolete flag.
    """

    def __init__(self, go_id, name, namespace, definition, is_obsolete=False):
        super().__init__(go_id, name, namespace, definition)

        self._parents = []
        self._children = []
        self._is_obsolete = is_obsolete

    @property
    def parents(self):
        return self._parents

    @property
    def children(self):
        return self._children

    @property
    def is_obsolete(self):
        return self._is_obsolete

    def add_parent(self, parent_id):
        if parent_id not in self._parents:
            self._parents.append(parent_id)

    def add_child(self, child_id):
        if child_id not in self._children:
            self._children.append(child_id)

    def describe(self):
        description = self._go_id + " - " + self._name
        description = description + " (" + self._namespace + ")"
        description = description + " [parents: " + str(len(self._parents))
        description = description + ", children: " + str(len(self._children)) + "]"
        if self._is_obsolete:
            description = description + " [OBSOLETE]"
        return description

    def get_info(self):
        info = super().get_info()
        info["parents"] = self._parents
        info["children"] = self._children
        info["is_obsolete"] = self._is_obsolete

        return info

    def __repr__(self):
        return "GOTerm(" + self._go_id + ")"


class BiologicalProcess(GOTerm):
    """
    A GO term that belongs to the biological_process namespace.
    Examples: cell division, DNA repair, signal transduction.
    """

    def __init__(self, go_id, name, definition, is_obsolete=False):
        super().__init__(go_id, name, "biological_process", definition, is_obsolete)

    def describe(self):
        base_description = super().describe()
        return "[BP] " + base_description

    def __repr__(self):
        return "BiologicalProcess(" + self._go_id + ")"


class MolecularFunction(GOTerm):
    """
    A GO term that belongs to the molecular_function namespace.
    Examples: kinase activity, DNA binding, transporter activity.
    """

    def __init__(self, go_id, name, definition, is_obsolete=False):
        super().__init__(go_id, name, "molecular_function", definition, is_obsolete)

    def describe(self):
        base_description = super().describe()
        return "[MF] " + base_description

    def __repr__(self):
        return "MolecularFunction(" + self._go_id + ")"


class CellularComponent(GOTerm):
    """
    A GO term that belongs to the cellular_component namespace.
    Examples: nucleus, mitochondrion, plasma membrane.
    """

    def __init__(self, go_id, name, definition, is_obsolete=False):
        super().__init__(go_id, name, "cellular_component", definition, is_obsolete)

    def describe(self):
        base_description = super().describe()
        return "[CC] " + base_description

    def __repr__(self):
        return "CellularComponent(" + self._go_id + ")"
import networkx as nx

from entity import BiologicalProcess
from entity import MolecularFunction
from entity import CellularComponent


class Ontology:
    """
    The Ontology class holds all GO terms and their relationships.
    It uses a NetworkX DiGraph (directed graph) to represent the
    hierarchy. Edges go from child to parent (child -> parent).
    """

    def __init__(self):
        self._graph = nx.DiGraph()
        self._terms = {}

    def build_from_data(self, terms_df, edges):
        """
        Build the ontology from a DataFrame of terms and a list of edges.

        Parameters:
        - terms_df: a pandas DataFrame with columns like
          'go_id', 'name', 'namespace', 'definition'
        - edges: a list of tuples like (child_id, parent_id)
          representing parent-child relationships
        """

        print("Building ontology...")

        count = 0

        for index, row in terms_df.iterrows():
            go_id = row["go_id"]
            name = row["name"]
            namespace = row["namespace"]
            definition = row["definition"]

            if "is_obsolete" in row:
                is_obsolete = row["is_obsolete"]
            else:
                is_obsolete = False

            if namespace == "biological_process":
                term = BiologicalProcess(go_id, name, definition, is_obsolete)
            elif namespace == "molecular_function":
                term = MolecularFunction(go_id, name, definition, is_obsolete)
            elif namespace == "cellular_component":
                term = CellularComponent(go_id, name, definition, is_obsolete)
            else:
                print("Warning: unknown namespace '" + str(namespace) + "' for " + str(go_id))
                continue

            self._terms[go_id] = term
            self._graph.add_node(go_id)

            count = count + 1

        print("  " + str(count) + " terms loaded.")

        edge_count = 0

        for edge in edges:
            child_id = edge[0]
            parent_id = edge[1]

            if child_id in self._terms and parent_id in self._terms:
                self._graph.add_edge(child_id, parent_id)
                edge_count = edge_count + 1

        print("  " + str(edge_count) + " edges loaded.")

        for child_id, parent_id in self._graph.edges():
            child_term = self._terms.get(child_id)
            parent_term = self._terms.get(parent_id)

            if child_term is not None and parent_term is not None:
                child_term.add_parent(parent_id)
                parent_term.add_child(child_id)

        print("Building ontology... done!")

    def get_term(self, go_id):
        """
        This function returns the GOTerm object for a given GO ID.
        If the GO ID is not found, it returns None.
        """

        result = self._terms.get(go_id, None)
        return result

    def get_parents(self, go_id):
        """
        This function returns a list of parent GOTerm objects
        for the given GO ID. Parents are one step up in the hierarchy.
        """

        term = self._terms.get(go_id)
        if term is None:
            return []

        result = []
        for parent_id in term.parents:
            parent_term = self._terms.get(parent_id)
            if parent_term is not None:
                result.append(parent_term)

        return result

    def get_children(self, go_id):
        """
        This function returns a list of child GOTerm objects
        for the given GO ID. Children are one step down in the hierarchy.
        """

        term = self._terms.get(go_id)
        if term is None:
            return []

        result = []
        for child_id in term.children:
            child_term = self._terms.get(child_id)
            if child_term is not None:
                result.append(child_term)

        return result

    def get_ancestors(self, go_id):
        """
        This function returns a set of all ancestor GOTerm objects.
        Ancestors are all terms above this one in the hierarchy
        (parents, grandparents, etc.). We use NetworkX to walk
        up the graph from the given node.
        """

        if go_id not in self._graph:
            return set()

        ancestor_ids = nx.descendants(self._graph, go_id)

        result = set()
        for ancestor_id in ancestor_ids:
            ancestor_term = self._terms.get(ancestor_id)
            if ancestor_term is not None:
                result.add(ancestor_term)

        return result

    def get_descendants(self, go_id):
        """
        This function returns a set of all descendant GOTerm objects.
        Descendants are all terms below this one in the hierarchy
        (children, grandchildren, etc.). We use NetworkX to walk
        down the graph from the given node.
        """

        if go_id not in self._graph:
            return set()

        descendant_ids = nx.ancestors(self._graph, go_id)

        result = set()
        for descendant_id in descendant_ids:
            descendant_term = self._terms.get(descendant_id)
            if descendant_term is not None:
                result.add(descendant_term)

        return result

    def get_subgraph(self, go_id, depth=2):
        """
        This function returns a list of GOTerm objects that are
        within N steps of the given GO ID. It looks both up (parents)
        and down (children) in the hierarchy.
        """

        if go_id not in self._graph:
            return []

        visited = set()
        visited.add(go_id)

        current_level = [go_id]

        for step in range(depth):
            next_level = []

            for node_id in current_level:
                for predecessor in self._graph.predecessors(node_id):
                    if predecessor not in visited:
                        visited.add(predecessor)
                        next_level.append(predecessor)

                for successor in self._graph.successors(node_id):
                    if successor not in visited:
                        visited.add(successor)
                        next_level.append(successor)

            current_level = next_level

        result = []
        for node_id in visited:
            term = self._terms.get(node_id)
            if term is not None:
                result.append(term)

        return result

    def search(self, keyword):
        """
        This function searches for GO terms whose name contains
        the given keyword. The search is case insensitive.
        Returns a list of matching GOTerm objects.
        """

        keyword_lower = keyword.lower()

        result = []
        for go_id in self._terms:
            term = self._terms[go_id]
            if keyword_lower in term.name.lower():
                result.append(term)

        return result

    def get_all_terms(self):
        """
        This function returns a list of all GOTerm objects
        stored in the ontology.
        """

        result = []
        for go_id in self._terms:
            result.append(self._terms[go_id])
        return result

    def get_terms_by_namespace(self, namespace):
        """
        This function returns a list of GOTerm objects that belong
        to the specified namespace. For example, you can pass
        "biological_process" to get only biological process terms.
        """

        result = []
        for go_id in self._terms:
            term = self._terms[go_id]
            if term.namespace == namespace:
                result.append(term)
        return result

    def total_terms(self):
        """
        This function returns the total number of terms in the ontology.
        It just returns the length of the terms dictionary.
        """

        return len(self._terms)
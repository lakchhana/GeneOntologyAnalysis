from entity import BiologicalProcess
from entity import MolecularFunction
from entity import CellularComponent
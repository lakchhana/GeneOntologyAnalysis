"""
data_loader.py
==============
This file has one main function: load_all_data().
It reads the OBO and GAF data files, builds the ontology and annotations,
and creates the similarity calculators. Then it returns everything
in a dictionary so the Flask app can use it.

This keeps the loading logic separate from the web app, which makes
the code easier to understand and test.
"""

import os
from parser.obo_parser import OBOParser
from parser.gaf_parser import GAFParser
from ontology.ontology import Ontology
from annotation.annotation import AnnotationManager
from analysis.similarity import JaccardSimilarity, OverlapSimilarity


def load_all_data():

    # The data folder is inside the same directory as this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    obo_file = os.path.join(data_dir, "go-basic.obo")
    gaf_file = os.path.join(data_dir, "goa_human.gaf.gz")

    # Check that both data files exist

    print("=" * 60)
    print("Loading Gene Ontology data...")
    print("=" * 60)
    if not os.path.exists(obo_file):
        raise FileNotFoundError(
            "Could not find the OBO file at: " + obo_file + "\n"
            "Please download go-basic.obo and place it in the data/ folder.\n"
            "You can get it from: http://purl.obolibrary.org/obo/go/go-basic.obo"
        )

    if not os.path.exists(gaf_file):
        raise FileNotFoundError(
            "Could not find the GAF file at: " + gaf_file + "\n"
            "Please download goa_human.gaf.gz and place it in the data/ folder.\n"
            "You can get it from: https://ftp.ebi.ac.uk/pub/databases/GO/goa/HUMAN/goa_human.gaf.gz"
        )

    print("Data files found!")
    print("  OBO file: " + obo_file)
    print("  GAF file: " + gaf_file)
    print()

    # Parse the OBO file to get GO terms and edges
    
    try:
        print("--- Parsing OBO file ---")
        obo_parser = OBOParser()
        terms_df, edges = obo_parser.parse(obo_file)
        print("OBO parsing complete!")
        print()
    except Exception as e:
        print("ERROR: Something went wrong while parsing the OBO file.")
        print("Details: " + str(e))
        raise

    #  Parse the GAF file to get gene annotations

    try:
        print("--- Parsing GAF file ---")
        gaf_parser = GAFParser()
        annotations_df = gaf_parser.parse(gaf_file)
        print("GAF parsing complete!")
        print()
    except Exception as e:
        print("ERROR: Something went wrong while parsing the GAF file.")
        print("Details: " + str(e))
        raise

    #  Build the Ontology from terms and edges
 
    try:
        print("--- Building Ontology ---")
        ontology = Ontology()
        ontology.build_from_data(terms_df, edges)
        print("Ontology built! Total terms: " + str(ontology.total_terms()))
        print()
    except Exception as e:
        print("ERROR: Something went wrong while building the ontology.")
        print("Details: " + str(e))
        raise

    #  Build the AnnotationManager from annotation rows

    try:
        print("--- Building Annotation Manager ---")
        am = AnnotationManager()
        am.build_from_data(annotations_df)
        summary = am.summary()
        print("Annotation manager built!")
        print("  Total annotations: " + str(summary["total"]))
        print()
    except Exception as e:
        print("ERROR: Something went wrong while building annotations.")
        print("Details: " + str(e))
        raise

    # Create the similarity calculators

    print("--- Creating similarity calculators ---")
    jaccard = JaccardSimilarity(am)
    overlap = OverlapSimilarity(am)
    print("Similarity calculators ready!")
    print()

    # Return everything in a dictionary

    print("=" * 60)
    print("All data loaded successfully!")
    print("=" * 60)
    print()

    result = {
        "ontology": ontology,
        "annotation_manager": am,
        "jaccard": jaccard,
        "overlap": overlap,
    }

    return result
